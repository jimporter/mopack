#include "hello.hpp"

#include <iostream>

namespace hello {
  void LIBHELLO_PUBLIC say_hello() {
    std::ccout << "hello, library!" << std::endl; // Typo!
  }
}
